Place your TensorFlow Lite model file named exactly "model.tflite" in this folder.
Ensure the model input/output shapes match what WasteClassifier expects, or adjust the code accordingly.

